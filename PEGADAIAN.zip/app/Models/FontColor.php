<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FontColor extends Model
{
    use HasFactory;

    protected $fillable = [
        'value',
        'name',
    ];
}
